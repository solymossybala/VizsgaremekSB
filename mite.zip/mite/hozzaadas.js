//az intolerancia 8 kategóriájának beemelése a legördülő listába
fetch('/mite/hozzaadas.php')
.then(function(valasz) {
return valasz.json(); 
}
)
    .then(valasz => {
        const hely = document.getElementById('intolerancia');
        valasz.forEach(intolerancia =>{
            const option = document.createElement('option');                                //HTML tag-t hoz létre, aminek írjuk a tulajdonságait: value, textContent
            option.value = intolerancia.id;
            option.textContent = intolerancia.intolerancia;
            hely.appendChild(option);
            console.log(option.textContent);
        });

    });
                                                                                     

document.getElementById('hozzadForm').addEventListener('submit', function(event){           //A submit eseményre bekötünk egy függvényt a hozzadForm-ban, ami egy POST kérést küld a szerver felé a Form adataival, és feldolgozza a választ.
    event.preventDefault()                                                                  //törli a submit esemény alapértelmezett cselekvést

    const adatok = new FormData(this);                                                      //A form adatainak kinyerésethis ez a hozzadForm 
    
    fetch('/mite/hozzaadas.php',{                                                           //kérés küldése metódus POST törzs az adatok
        method: 'POST',
        body: adatok
    })
    .then(valasz => valasz.text())
    .then(szoveg => {                                                                       //sikeres adatrögzítés
        alert(szoveg)
        window.location.href = "index.html"                                                 //visszaküldöm aiz index.html-re
    })
})