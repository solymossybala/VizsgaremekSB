<?php
require_once('kapcsolat.php');                                                              // Kapcsolat létrehozása az adatbázissal
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
// Ha a kérés metódusa POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (                                                                                    // Ellenőrizni kell, hogy megérkeztek-e az adatok a szerver oldalra
        isset($_POST['intolerancia']) &&
        isset($_POST['megnevezes']) &&
        isset($_POST['elkeszites']) &&
        isset($_POST['kep'])
    ) 
    {
        $intolerancia = $_POST['intolerancia'];                                             // Adatok kinyerése az űrlapról
        $megnevezes = $_POST['megnevezes'];
        $elkeszites = $_POST['elkeszites'];
        $kep = $_POST['kep'];
       
        $query = "INSERT INTO etel (megnevezes, intolerancia_id, elkeszites, kep)            
                    VALUES ('$megnevezes','$intolerancia',  '$elkeszites', '$kep')";        // SQL lekérdezés az adatok beszúrására az adatbázisba
        $result =  mysqli_query($conn, $query);                                             //$result változó tartalmát belerakjuk egy PHP objektumokat tartalmazó tömbbe
       
        if ($result) {                                                                      // Ellenőrizzük, hogy van-e eredmény
            echo "Sikeres feltöltés";                                                       // Az intolerancia azonosítóját mentjük
        } else {                                                                            // Ha nem sikerült lefuttatni a lekérdezést
            echo "Hiányos adatok";
        }
    }
}

elseif($_SERVER["REQUEST_METHOD"] === "GET"){
    $query = "SELECT id, intolerancia FROM intolerancia";                                   //SQL lekérdezés (intolerancia tábla minden adata kell)
    $result =  mysqli_query($conn, $query);                                                 //lekérdezés futtatása
    $intolerancia = [];                                                                    //$result változó tartalmát belerakjuk egy PHP objektumokat tartalmazó tömbbe
    
    if($result){                                                                            //ha van a lekérdezésnek eredménye (ha igaz)
        
        while($row = mysqli_fetch_assoc($result)){                                          //végimegyünk a visszaadott eredményen: $result, $row változóba egy eleme kerül a $result-nak
            $erzekenyseg = [
                'id' => $row['id'],
                'intolerancia' => $row['intolerancia']
            ];
           
            $intolerancia[] = $erzekenyseg;                                                  //fűzzük a $intolerancia tömb végére
        }
        header('Content-Type: application/json');
        echo json_encode($intolerancia);
    }
    else{                                                                                       //nincs eredmény--> $result értéke null
        header('Content-Type: application/json');
        echo json_encode(['uzenet' => 'Hiba az adatok lekérdezésében!']);
    }
}
        
