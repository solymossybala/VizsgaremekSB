
        function lekerdezes() {
            // Kiválasztott intoleranciák tömbjének előkészítése
            const intoleranciak = [];
            
            if (document.getElementById("laktozmentes").checked) intoleranciak.push("Laktózmentes");
            if (document.getElementById("glutenmentes").checked) intoleranciak.push("Gluténmentes");
            if (document.getElementById("husmentes").checked) intoleranciak.push("Húsmentes");
            if (document.getElementById("normal").checked) intoleranciak.push("Normál");
            
            fetch('index.php')
                .then(adat => adat.json())
                .then(adat => {
                    const hely = document.getElementById("etelek");
                    hely.innerHTML = "";
                    
                    adat.forEach(etel => {
                            //console.log(etel.intolerancia.split(' '))        
                            let van = true

                            intoleranciak.forEach(into => {
                                if (etel.intolerancia.split(' ').indexOf(into) < 0) {
                                    van = false
                                }
                            })
                            if (van) {
                                const sor = document.createElement('tr');
                                sor.innerHTML = `
                                    <td id="sorszam">${etel.id}</td> 
                                    <td id="erzekenyseg">${etel.intolerancia}</td> 
                                    <td id="receptNeve">${etel.megnevezes}
                                    <br>
                                    <button type="submit" class="kedvencekGomb">Kedvencekhez adom</button>
                                    </td>
                                    <td id="receptTartalom">${etel.elkeszites}</td> 
                                    <td id="receptKepe"><img src="${etel.kep}" alt="recept képe"></td>`;
                                hely.appendChild(sor);
                            }

                    });
                })
                .catch(error => console.error('Hiba történt:', error));
        }

        lekerdezes();

        document.addEventListener("click", function(){
            lekerdezes();
        })

    // kedvencekGomb beállíátsa
    document.getElementById('etelek').addEventListener('submit', function(event){
        event.preventDefault()                                                                  //törli a submit esemény alapértelmezett cselekvést
    
        const adatok = new TableData(this);                                                     //A táblázat adatainak kinyerése (this: ez az etelek táblázat) 
        
        fetch('/mite/kedvencek.php',{                                                           //kérés küldése metódus POST törzs az adatok
            method: 'POST',
            body: adatok
        })
        .then(valasz => valasz.text())
        .then(szoveg => {                                                                       //sikeres adatrögzítés
            alert(szoveg)
            window.location.href = "index.html"                                                 //visszaküldöm az index.html-re
        })
        
    })