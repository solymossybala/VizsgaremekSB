//Regisztráció
document.getElementById('registrationForm').addEventListener('submit', function(event){
  event.preventDefault()                                                                    //törli a submit esemény alapértelmezett cselekvést

  const adatok = new FormData(this);                                                        

  fetch('/mite/regisztracio.php',{                                                          //kérés küldése POST metódussal (a törzs tartalmazza az adatokat)
      method: 'POST',
      body: adatok
  })
  .then(valasz => valasz.text())
  .then(szoveg => {                                                                         //sikeres adatrögzítés
      alert(szoveg)
      window.location.href = "index.html"                                                   //visszaküldöm az index.html-re
  })
})


//Bejelentkezés
document.getElementById('loginForm').addEventListener('submit', function(event){
  event.preventDefault()                                                                    //törli a submit esemény alapértelmezett cselekvést

  const adatok = new FormData(this);                                                        //A form adatainak kinyerése (this ez a registrationForm) 

  fetch('/mite/bejelentkezes.php',{                                                         //kérés küldése POST metódussal (a törzs tartalmazza az adatokat)
      method: 'POST',
      body: adatok
  })
  .then(valasz => valasz.text())
  .then(szoveg => {                                                                         //sikeres adatrögzítés
      alert(szoveg)
      window.location.href = "index.html"                                                   //visszaküldöm aiz index.html-re
  })
})

