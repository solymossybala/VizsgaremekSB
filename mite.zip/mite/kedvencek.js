function lekerdezes() {
           
    fetch('kedvencek.php')
        .then(adat => adat.json())
        .then(adat => {
            const hely = document.getElementById("kedvencek");
            hely.innerHTML = "";
            
            adat.forEach(etel => {
                    const sor = document.createElement('tr');
                        sor.innerHTML = `
                            <td id="id">${etel.id}</td> 
                            <td id="erzekenyseg">${etel.intolerancia}</td> 
                            <td id="receptNeve">${etel.megnevezes}
                            <br>
                            <button type="submit" class="torlesGomb">Törlés</button>
                            </td>
                            <td id="receptTartalom">${etel.elkeszites}</td> 
                            <td id="receptKepe"><img src="${etel.kep}" alt="recept képe"></td>`;
                        hely.appendChild(sor);
                    })

            });
        }

lekerdezes();

document.addEventListener("click", function(){
    lekerdezes();
});


//Törlés gomb beállítása
document.getElementById('kedvencek').addEventListener('submit', function(event){
    event.preventDefault();
    const id = document.getElementById('id').value;                            // kivesszük az input mező értékét, a törlendő elem id-jét
    fetch(`kedvencektorlese.php?id=${id}`, {                                   // Itt kell egy kedvencek törlése php
        method: 'DELETE'
    })
    .then(valasz => {
        if (!valasz.ok) {
            throw new Error('Hiba történt a törlésnél');
        }
        return valasz.text();
    })
    .then(szoveg => {
        if (szoveg) {                                                           // ha nem üres szöveg
            alert(szoveg);
        }
         window.location.href = "index.html";                                   // csak akkor navigálunk, ha a törlés sikeres volt
    })
    .catch(error => {
        console.error('Hiba: ', error);
    });
});

   