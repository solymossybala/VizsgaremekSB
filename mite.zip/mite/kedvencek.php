<?php
require_once("kapcsolat.php");
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");


//KEDVENCEK BEOLVASÁSA
$felhasznalok = 2;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            
        $sql = "SELECT etel.id, etel.megnevezes, etel.elkeszites, etel.kep, intolerancia.intolerancia 
                FROM etel 
                INNER JOIN intolerancia ON etel.intolerancia_id = intolerancia.id
                INNER JOIN kedvencek ON etel.id = kedvencek.etel_id
                INNER JOIN felhasznalok ON kedvencek.felhasznalok_id = felhasznalok.id
                WHERE kedvencek.felhasznalok_id = '$felhasznalok'";

        $result = mysqli_query($conn, $sql); 
        
        if (mysqli_num_rows($result) > 0) {                                                                                              // Ellenőrzés: vannak-e kedvencek
            $kedvencek = [];                                                                                                             // Ha vannak kedvencek, létrehozunk egy üres tömböt

            while ($row = mysqli_fetch_assoc($result)) {                                                                                 // A lekérdezett adatok hozzáadása a tömbhöz
                $kedvenc = [  
                    'id' => $row['id'], 
                    'intolerancia' => $row['intolerancia'],                
                    'megnevezes' => $row['megnevezes'],
                    'elkeszites' => $row['elkeszites'],
                    'kep' => $row['kep'],
                ];
    
                $kedvencek[] = $kedvenc;                                                                                                    //tömb végére teszi az új receptet    
            }
        
        header('Content-Type: application/json');                                                                                           //JSON-né alakítom
        echo json_encode($kedvencek);
        
        } else {                                                                                                                        // Ha nincsenek kedvencek az adatbázisban
            echo json_encode(['uzenet' => 'Nincsenek kedvencek ehhez az ételhez']);
        }
    } else {                                                                                                                        // Hiányzó adatok esetén
       
        echo json_encode(['uzenet' => 'Hiányzó adatok']);
    }
?>