<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "miteszunk";

$conn = mysqli_connect($servername, $username, $password, $dbname);             //csatlakozás az adatbázishoz $conn változón keresztül
if(!$conn)                                                                      //ha a kapcsolat nem jött létre (nincs értéke a $conn változónak)
{
    die("Sikertelen kapcsolódás az adatbázishoz: " . mysqli_connect_error());   //mysqli_connect_error() --> megadja a hiba okát (. az összefűzés)
}