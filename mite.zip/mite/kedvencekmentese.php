<?php
require_once("kapcsolat.php");
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");

// KEDVENCEK MENTÉSE AZ ADATBÁZISBA
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (                                                            // Ellenőrizni kell, hogy megérkeztek-e az adatok a szerver oldalra
        isset($_POST['etel_id']) &&
        isset($_POST['felhasznalo_id'])
    ) 
    {
    $etel_id = $_POST['etel_id'];
    $felhasznalo_id = $_POST['felhasznalo_id'];
    
    $sql = "INSERT INTO kedvencek (etel_id, felhasznalo_id)         
            VALUES ('$etel_id', '$felhasznalok')";                // SQL lekérdezés az adatok beszúrására az adatbázisba

    $result =  mysqli_query($conn, $query);                         //$result változó tartalmát belerakjuk 
                                                                    //egy PHP objektumokat tartalmazó tömbbe
        if ($result) {                                              // Ellenőrizzük, hogy van-e eredmény
            echo "Sikeres feltöltés";                              
        } else {                                                    // Ha nem sikerült lefuttatni a lekérdezést
            echo "Hiányos adatok";
        }   
    }
}
?>