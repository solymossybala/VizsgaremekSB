<?php
require_once("kapcsolat.php");
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");


if($_SERVER["REQUEST_METHOD"] === "POST"){                                  //új felhasználó adatainak felvétele
        if(                                                                 //megérkeztek-e az adatok a szerver oldalra
            isset($_POST['regEmail']) &&
            isset($_POST['regPassword'])      
        )
        {
            $email = $_POST['regEmail'];                                       //adatok eltárolása PHP változókba
            $jelszo = $_POST['regPassword'];
        
            $sql = "INSERT INTO felhasznalok (email, jelszo)                 
                    VALUES ('$email','$jelszo')";                           //rekord beszúrására a felhasználók táblába (ha sikeres volt, akkor belemegy az if-be)
            
            if(mysqli_query($conn, $sql)){                                  //sikeres a beszúrás, http_response_code(201); válasz státusza --> OK
                $ujId = mysqli_insert_id($conn);                            //megkapjuk a beszúrt rekord id-jét (mivel az id AUTO INCREMENT),
                header('Content-Type: application/json');                   //JSON-né alakítjuk
                echo json_encode(['id' => $ujId]);                          //üzenet kilens felé: egy id kulcsra az ujId értékét helyeztük, jsonné alakítva 
            }
            else{                                                           //nem sikerül az adatok beillesztése: http_response_code(400);
                header('Content-Type: application/json');                   //JSON-el kommunikálunk
                echo json_encode(['uzenet' => 'Sikertelen beszúrás']);
            }
        }
    }

