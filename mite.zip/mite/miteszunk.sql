-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Máj 04. 23:20
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `miteszunk`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `etel`
--

CREATE TABLE `etel` (
  `id` int(11) NOT NULL,
  `megnevezes` varchar(100) NOT NULL,
  `intolerancia_id` int(11) DEFAULT NULL,
  `elkeszites` text DEFAULT NULL,
  `kep` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `etel`
--

INSERT INTO `etel` (`id`, `megnevezes`, `intolerancia_id`, `elkeszites`, `kep`) VALUES
(1, 'Zabkása', 8, 'HOZZÁVALÓK\r\n1.5 bögre víz, 3tk méz, 1 bögre zabpehely, 1tk fahéj, 1db alma\r\n\r\nELKÉSZÍTÉS\r\nA vizet melegíteni kezdjük, majd belekeverjük a mézet. Ha felforrt, hozzákeverjük a zabpelyhet is, levéve a tűzhelyről fedő alatt 5 percig hagyjuk puhulni. Ha felvette az összes folyadékot, meghintjük a fahéjjal.\r\nA megmosott és szárazra törölt almát kis darabokra vagy cikkekre vágjuk, és a zabkására halmozva kínáljuk.', 'img/zabkasa.jpg'),
(3, 'Egyszerű sajtkrémleves', 3, 'HOZZÁVALÓK\r\n1db leveskocka, 10 dkg füstölt sajt, 1 ek liszt, 2 dl tejszín, só, 4 szelet barna kenyér\r\n\r\nELKÉSZÍTÉS\r\nA sajtkrémleves elkészítéséhez a leveskockát felfőzzük 6 dl vízzel, majd beletesszük a kétféle lereszelt sajtot, és kis lángon addig főzzük, amíg a sajt felolvad.\r\nHabverővel simára keverjük a lisztet 1 dl vízben, és a leveshez adjuk. Hozzáöntjük a tejszínt, és kevergetve 5 percig főzzük. Azután felforraljuk, és megsózzuk.\r\nA kenyérszeleteket felkockázzuk, és megpirítjuk őket. Ezekkel tálaljuk a krémlevest.', 'img/egyszeru-sajtkremleves.jpg'),
(5, 'Spagetti carbonara', 4, 'HOZZÁVALÓK\r\n40dkg spagetti, só, 1 gerezd	fokhagyma, 10dkg bacon, 2ek olívaolaj, 3dl cukrozatlan habtejszín, 1db tojássárgája, parmezán\r\n\r\nELKÉSZÍTÉS\r\nA tésztát forrásban lévő, sós vízben kifőzzük, a csomagoláson olvasható útmutatás szerint. Ezután leszűrjük, lecsepegtetjük, és melegen tartjuk.\r\nKözben meghámozzuk és összezúzzuk a fokhagymát. A bacont felaprítjuk. Felforrósítjuk az olajat, és megfonnyasztjuk rajta a fokhagymát. Hozzáadjuk a bacont, kissé megpirítjuk. Felöntjük az egészet a tejszínnel, és felforraljuk.\r\nLehúzzuk a tűzről, hozzáadjuk a tojássárgáját, elkeverjük, végül összeforgatjuk a mártást a főtt tésztával. Frissen reszelt sajttal megszórva tálaljuk.	', 'img/spaghetti_carbonara.jpg'),
(8, 'Répatorta', 4, 'HOZZÁVALÓK\r\nA tortához: 10dkg dió + a szóráshoz, 35dkg sárgarépa, 14dkg liszt, 14dkg rétesliszt, 2tk sütőpor, 1tk fahéj, 1csipet só, 4db tojás, 30dkg barna cukor, 2tk vaníliás cukor, 1.5dl napraforgóolaj, vaj a tepsi kenéséhez	\r\nA krémhez: 5dkg vaj, 25dkg krémsajt (Mascarpone), 1rúd vanília kikapart belseje, 1db citrom reszelt héja, 20dkg porcukor\r\n\r\nELKÉSZÍTÉS\r\nA diót száraz serpenyőben megpirítjuk, majd amikor már kellően illatozik, deszkára halmozzuk, és durvára vágjuk. A répát megpucoljuk, lereszeljük.\r\nEgy mély tálba öntjük a liszteket, hozzákeverjük a sütőport, a fahéjat és a sót.\r\nHabosra verjük a tojásokat a cukorral és a vaníliás cukorral, majd hozzákeverjük az olajat. Hozzáöntjük a lisztes keveréket, és alaposan összedolgozzuk. Ezután hozzáadjuk a lecsöpögtetett reszelt sárgarépát és a pirított diót.\r\nAlaposan összeforgatjuk, majd kivajazott tortaformába öntjük, és 180 fokra előmelegített sütőben 30-40 percig sütjük. Tűpróbával ellenőrizzük. A répatortát kihűtjük, majd hosszában félbevágjuk.\r\nA nem túl hideg vajat a krémsajttal habosra keverjük, majd hozzáadjuk a vanília kikapart belsejét, a citrom lereszelt héját és a porcukrot. Alaposan elkeverjük.\r\nA mascarponés krémmel megkenjük a torta alsó részét. Rátesszük a tetejét, és körbekenjük a maradék krémmel. Néhány órára a hűtőben tesszük. Dióval megszórva kínáljuk.', 'img/repatorta.jpeg'),
(9, 'Görögös csirkecomb bazsalikomos sült paradicsommal', 5, 'HOZZÁVALÓK\r\nA húshoz: só, bors, 1ág friss oregánó, 1marék friss bazsalikomlevél, 1tk őrölt pirospaprika, 2levél friss menta, 4db csirkecomb, 1tk libazsír vagy kacsazsír\r\nA paradicsomhoz: 50dkg koktélparadicsom, 1ek olívaolaj, 2gerezd fokhagyma, 1fej lila hagyma, 1csok friss bazsalikom, 1csok petrezselyemzöld, 1marék gyöngyhagyma, só\r\n\r\nELKÉSZÍTÉS\r\nA görögös csirkecomb elkészítéséhez egy kis tálban összekeverjük a fűszereket: sót, durvára darált borsot, az elmorzsolt vagy összevágott oregánót, a bazsalikomot, a mentát és a pirospaprikát. Bedörzsöljük vele a csirkecombokat, majd zsírral kikent tepsibe lerakjuk, a tetejére locsoljuk a maradék megolvasztott zsírt, és öntünk alá fél deci vizet.\r\nAlufóliával lezárjuk, és 180 fokos sütőben 50 percig sütjük. Levesszük róla a takarást, és magasabb hőfokon kicsit megpirítjuk a tetejét.\r\nA bazsalikomos sült paradicsom elkészítéséhez a paradicsomokat elfelezzük (ha kicsi, maradhat egészben is). Forró olívaolajban fél percig pirítjuk a felszeletelt fokhagymát. Rádobjuk a nagyobb kockára vágott lila hagymát, az összevágott bazsalikomot és petrezselyem zöldjét, beleszórjuk a gyöngyhagymát.\r\nSózzuk, kicsit összepároljuk, végül rádobjuk a paradicsomot, és addig sütjük együtt, míg a paradicsom kicsit összeesik, de még szépen egyben marad.\r\nA csirkecombokat a bazsalikomos sült paradcsommal tálaljuk.', 'img/gorog-csirkecombok.jpg'),
(10, 'Friss görög saláta', 8, 'HOZZÁVALÓK\r\n1db kígyóuborka, 4db paradicsom, 1db lila hagyma, 15dkg olívabogyó, 0.5db citrom leve, só, bors, 1tk oregano, 20dkg feta sajt, 4ek olívaolaj\r\n\r\nELKÉSZÍTÉS\r\nA zöldségeket megtiszítjuk, megmossuk, szárazra töröljük, és felaprítjuk. \r\nEgy tálban összekeverjük az uborkát, a paradicsomot, a lila hagymát és az olívabogyót, majd meglocsoljuk a citromlével, és összekeverjük.\r\nMegsózzuk, megborsozzuk, megszórjuk oregánóval, majd hozzáadjuk a felkockázott feta sajtot.\r\nVégül meglocsoljuk az olívaolajjal, összekeverjük, és néhány órára a hűtőbe tesszük.', 'img/friss-gorog-salata.jpg'),
(11, 'Sajtos melegszendvics', 3, 'HOZZÁVALÓK\r\nszelet teljes kiőrlésű kenyér, vaj, 6szelet sajt\r\n\r\nELKÉSZÍTÉS\r\nMind a 4 szelet kenyeret megkenjük vajjal. Két szeletre ráteszünk 3-3 szelet sajtot, majd befedjük a maradék kenyérrel.\r\nEgy serpenyőben vajat hevítünk, és kb. 2-2 perc alatt megsütjük a szendvicsek mindkét oldalát. Melegen tálaljuk. \r\n	', 'img/melegszendvics.jpg'),
(12, 'Sajtos melegszendvics', 3, 'HOZZÁVALÓK\r\nszelet teljes kiőrlésű kenyér, vaj, 6szelet sajt\r\n\r\nELKÉSZÍTÉS\r\nMind a 4 szelet kenyeret megkenjük vajjal. Két szeletre ráteszünk 3-3 szelet sajtot, majd befedjük a maradék kenyérrel.\r\nEgy serpenyőben vajat hevítünk, és kb. 2-2 perc alatt megsütjük a szendvicsek mindkét oldalát. Melegen tálaljuk. \r\n	', 'img/melegszendvics.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasznalok`
--

CREATE TABLE `felhasznalok` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jelszo` varchar(100) NOT NULL,
  `belepesIdeje` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `felhasznalok`
--

INSERT INTO `felhasznalok` (`id`, `email`, `jelszo`, `belepesIdeje`) VALUES
(1, 'renata.szerencse@gmail.com', 'sargarepa', '2024-05-04 14:51:24'),
(2, 'kockacukor1999@gmail.com', 'marabu', '2024-04-28 13:32:40'),
(3, 'hajnaka77@gmail.com', 'akarmi', '2024-05-04 14:38:16'),
(4, 'kivagyok@gmail.com', 'valaki', '2024-05-04 14:43:05'),
(5, 'semmiextra@citromail.hu', 'semmiextra', '2024-05-04 14:47:36');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `intolerancia`
--

CREATE TABLE `intolerancia` (
  `id` int(11) NOT NULL,
  `intolerancia` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `intolerancia`
--

INSERT INTO `intolerancia` (`id`, `intolerancia`) VALUES
(1, 'Laktózmentes'),
(2, 'Gluténmentes'),
(3, 'Húsmentes'),
(4, 'Normál'),
(5, 'Laktózmentes Gluténmentes'),
(6, 'Laktózmentes Húsmentes'),
(7, 'Gluténmentes Húsmentes'),
(8, 'Laktózmentes Gluténmentes Húsmentes');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kedvencek`
--

CREATE TABLE `kedvencek` (
  `id` int(11) NOT NULL,
  `felhasznalok_id` int(11) DEFAULT NULL,
  `etel_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `kedvencek`
--

INSERT INTO `kedvencek` (`id`, `felhasznalok_id`, `etel_id`) VALUES
(1, 2, 3),
(2, 2, 9),
(3, 2, 10),
(4, 2, 8),
(5, 1, 1),
(6, 1, 5),
(7, 1, 11);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `etel`
--
ALTER TABLE `etel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `intolerancia_id` (`intolerancia_id`);

--
-- A tábla indexei `felhasznalok`
--
ALTER TABLE `felhasznalok`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `intolerancia`
--
ALTER TABLE `intolerancia`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `kedvencek`
--
ALTER TABLE `kedvencek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `felhasznalok_id` (`felhasznalok_id`),
  ADD KEY `etel_id` (`etel_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `etel`
--
ALTER TABLE `etel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT a táblához `felhasznalok`
--
ALTER TABLE `felhasznalok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `intolerancia`
--
ALTER TABLE `intolerancia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `kedvencek`
--
ALTER TABLE `kedvencek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `etel`
--
ALTER TABLE `etel`
  ADD CONSTRAINT `etel_ibfk_1` FOREIGN KEY (`intolerancia_id`) REFERENCES `intolerancia` (`id`);

--
-- Megkötések a táblához `kedvencek`
--
ALTER TABLE `kedvencek`
  ADD CONSTRAINT `kedvencek_ibfk_1` FOREIGN KEY (`felhasznalok_id`) REFERENCES `felhasznalok` (`id`),
  ADD CONSTRAINT `kedvencek_ibfk_2` FOREIGN KEY (`etel_id`) REFERENCES `etel` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
