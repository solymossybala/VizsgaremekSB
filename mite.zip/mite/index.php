<?php
//kapcsolat létrehozása a kapcsolat.php importlásával:
require_once("kapcsolat.php");
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");

if($_SERVER["REQUEST_METHOD"] === "GET"){                                                               //visszaadja az ételek összes adatát JSON formátumban (metódus: GET)
    $query = "SELECT intolerancia.intolerancia, etel.id, etel.megnevezes, etel.elkeszites, etel.kep 
              FROM etel
              INNER JOIN intolerancia
              ON etel.intolerancia_id=intolerancia.id;";
    $result = mysqli_query($conn, $query);                                                              //a lekérdezés futtatása a $conn-ban lévő kapcsolaton keresztül
    
    if($result){                                                                                        //ha van eredménye a lekérdezésnek ($result igaz), a tartalmát (PHP objektumokat) beletesszük egy $etelek nevű tömbbe
        $etelek = [];                                                                                   //végig kell menni a $result elemein: $row = mysqli_fecth_assoc($result)
        while($row = mysqli_fetch_assoc($result)){                                                      //minden elemet beletesz a $row változóba, ami kulcs érték párokat tartalmazó objektum, (a kulcs a SELECT-ben megadott oszlopnév)
            $etel = [                                                                                   //kulcs=>érték párokat tartalmazó tömb; kulcsok az adattáblák attribútumai, illetve AS átnevezés eredménye
                'id' => $row['id'], 
                'intolerancia' => $row['intolerancia'],                
                'megnevezes' => $row['megnevezes'],
                'elkeszites' => $row['elkeszites'],
                'kep' => $row['kep'],
            ];
            $etelek[] = $etel;                                                                          //tömb végére teszi az új receptet
        }
        header('Content-Type: application/json');                                                       //JSON-né alakítom
        echo json_encode($etelek);
    }
    else{
        echo json_encode(['uzenet' => 'Hiba az adatok lekérdezésekor']);
    } 
}

