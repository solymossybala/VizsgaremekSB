<?php
require_once('kapcsolat.php');                                                                  // Kapcsolat létrehozása az adatbázissal
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");
                                                                                                                
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {                          // Ha a kérés metódusa DELETE
                                                                                        
    if (isset($_GET['id'])) {                                           // Ellenőrizni kell, hogy megérkeztek-e az adatok a szerver oldalra                                                             
        $id = $_GET['id'];                                              // A törlendő elem azonosítója                                                          
        $query = "SELECT etel_id FROM kedvencek WHERE etel_id='$id'";   // SQL lekérdezés a törlendő elem kiválasztására      
        $result = mysqli_query($conn, $query);                          // Lekérdezés futtatása
                                    
        if (mysqli_num_rows($result) > 0) {                             // Ellenőrizni kell, hogy van-e eredmény a lekérdezésnek                                                            
            $sql = "DELETE FROM kedvencek WHERE etel_id='$id'";         // Ha van eredmény, akkor töröljük az adott rekordot
            
            if (mysqli_query($conn, $sql)) {                            // Sikeres törlés esetén visszaküldhetünk egy üzenetet a kliens oldalra                                                            
                echo "A recept sikeresen törölve.";
            } else {                             
                echo "Hiba történt a törlés során.";                    // Hiba esetén visszaküldhetünk egy hibaüzenetet a kliens oldalra
            }

        } else {                                                                      
            echo "Nem található recept az adott azonosítóval.";         // Ha nincs eredmény, akkor a megadott azonosítóval nem található recept
        }
    } else {                                                                         
        echo "Nincs megadva azonosító a törléshez.";                    // Ha nem érkezett meg az azonosító a szerverre
    }
} else {                                                            
    echo "Hibás kérési metódus.";                                       // Ha a kérés metódusa nem DELETE
}
?>
