<?php
//kapcsolat létrehozása
require_once('kapcsolat.php');
//metódus lekérdezése (GET)
if($_SERVER["REQUEST_METHOD"] === "GET"){
    //SQL lekérdezés (intolerancia tábla minden adata kell)
    $query = "SELECT id, intolerancia FROM intolerancia";

    //lekérdezés futtatása
    $result =  mysqli_query($conn, $query);
    //$result változó tartalmát belerakjuk egy PHP objektumokat tartalmazó tömbbe
    $intolerancia = [];
    //ha van a lekérdezésnek eredménye (ha igaz)
    if($result){
        //végimegyünk a visszaadott eredményen $result
        while($row = mysqli_fetch_assoc($result)){ //$row változóba egy eleme kerül a $result-nak
            $erzekenyseg = [
                'id' => $row['id'],
                'intolerancia' => $row['intolerancia']
            ];
            //fűzzük a $intolerancia tömb végére
            $intolerancia[] = $erzekenyseg;
        }
        header('Content-Type: application/json');
        echo json_encode($intolerancia);
    }
    else{ //nincs eredmény--> $result értéke null
        header('Content-Type: application/json');
        echo json_encode(['uzenet' => 'Hiba az adatok lekérdezésében!']);
    }
}
?>