<?php
require_once("kapcsolat.php");
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");


if($_SERVER["REQUEST_METHOD"] === "GET"){
    $query = "SELECT email, jelszo FROM felhasznalok";
    $result =  mysqli_query($conn, $query);
    
    $felhasznalok = [];
    
    if($result){
        
        while($row = mysqli_fetch_assoc($result)){ 
            $felhasznalo = [
                'email' => $row['loginEmail'],
                'jelszo' => $row['loginPassword']
            ];
            
            $felhasznalok[] = $felhasznalo;
        }
        header('Content-Type: application/json');
        echo json_encode(['uzenet' => 'Sikeres bejelentkezés']);
    }
    else{ 
        header('Content-Type: application/json');
        echo json_encode(['uzenet' => 'Hibás felhasználónév vagy jelszó']);
    }
}

?>